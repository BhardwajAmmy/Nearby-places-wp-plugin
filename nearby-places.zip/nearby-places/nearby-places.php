<?php
/*
Plugin Name: Nearby Places Map
Description: Displays a map and nearby places using Leaflet and Overpass API
Version: 2.1
Author: Amit Bhardwaj
*/

function npm_enqueue_scripts() {
    wp_enqueue_style('leaflet-css', 'https://unpkg.com/leaflet@1.7.1/dist/leaflet.css');
    wp_enqueue_script('leaflet-js', 'https://unpkg.com/leaflet@1.7.1/dist/leaflet.js', array(), null, true);

    $plugin_url = plugin_dir_url(__FILE__);

    wp_enqueue_style('npm-custom-css', $plugin_url . 'css/nearby-places.css');
    wp_enqueue_script('npm-custom-js', $plugin_url . 'js/nearby-places.js', array('jquery', 'leaflet-js'), false, true);

    wp_localize_script('npm-custom-js', 'npm_data', array(
        'plugin_url' => $plugin_url,
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('npm_nonce'),
        'filter_icons' => npm_get_filter_icons()
    ));
}
add_action('wp_enqueue_scripts', 'npm_enqueue_scripts');

function npm_get_categories() {
    return array(
        'restaurants' => array('amenity' => 'restaurant'),
        'banks' => array('amenity' => 'bank'),
        'bars' => array('amenity' => 'bar'),
        'shopping' => array('shop' => 'mall'),
        'grocery' => array('shop' => 'supermarket'),
        'hospitals' => array('amenity' => 'hospital'),
        'police' => array('amenity' => 'police'),
        'schools' => array('amenity' => 'school'),
        'transit' => array('amenity' => 'bus_station'),
        'parks' => array('leisure' => 'park'),
        'fire_station' => array('amenity' => 'fire_station'),
        'place_of_worship' => array('amenity' => 'place_of_worship'),
        'gyms' => array('leisure' => 'fitness_centre')
    );
}

function npm_get_filter_icons() {
    return array(
        'restaurants' => 'filter-restaurant.png',
        'banks' => 'filter-bank.png',
        'bars' => 'filter-bar.png',
        'shopping' => 'filter-shopping.png',
        'grocery' => 'filter-grocery.png',
        'hospitals' => 'filter-hospital.png',
        'police' => 'filter-police.png',
        'schools' => 'filter-school.png',
        'transit' => 'filter-transport.png',
        'parks' => 'filter-park.png',
        'fire_station' => 'filter-fire-station.png',
        'place_of_worship' => 'filter-place-of-worship.png',
        'gyms' => 'filter-gym.png'
    );
}

function npm_overpass_proxy() {
    check_ajax_referer('npm_nonce', 'nonce');

    $lat = floatval($_POST['lat']);
    $lng = floatval($_POST['lng']);
    $radius = intval($_POST['radius']);
    $filter = $_POST['filter'];

    if (!$lat || !$lng || !$filter) {
        wp_send_json_error(['message' => 'Missing parameters']);
    }

    $filter_key = key($filter);
    $filter_value = $filter[$filter_key];

    $query = '[out:json][timeout:25];
(
  node["' . $filter_key . '"="' . $filter_value . '"](around:' . $radius . ',' . $lat . ',' . $lng . ');
  way["' . $filter_key . '"="' . $filter_value . '"](around:' . $radius . ',' . $lat . ',' . $lng . ');
  relation["' . $filter_key . '"="' . $filter_value . '"](around:' . $radius . ',' . $lat . ',' . $lng . ');
);
out center;';

    $response = wp_remote_post("https://overpass-api.de/api/interpreter", [
        'body' => $query,
        'timeout' => 20
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error(['message' => 'Overpass error']);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    if (!$body || !isset($body['elements'])) {
        wp_send_json_error(['message' => 'Invalid Overpass response']);
    }

    // Return FLAT array — required for JS
    wp_send_json_success($body['elements']);
}

add_action('wp_ajax_npm_overpass_proxy', 'npm_overpass_proxy');
add_action('wp_ajax_nopriv_npm_overpass_proxy', 'npm_overpass_proxy');

function npm_nearby_places_shortcode($atts) {
    global $post;

    $lat = get_post_meta($post->ID, 'ea5d118be0af6fd4328c88a53e775826_lat', true);
    $lng = get_post_meta($post->ID, 'ea5d118be0af6fd4328c88a53e775826_lng', true);

    if (!$lat || !$lng) {
        return '<p>Location data missing.</p>';
    }

    $categories = npm_get_categories();
    $icons = npm_get_filter_icons();
    $plugin_url = plugin_dir_url(__FILE__);

    ob_start();
?>
<div id="npm-container">
    <div id="npm-map"></div>

    <div class="npm-category-filters">
        <?php foreach ($icons as $key => $icon): ?>
            <span class="npm-filter" data-category="<?php echo $key; ?>">
                <img src="<?php echo $plugin_url . 'img/' . $icon; ?>">
            </span>
        <?php endforeach; ?>
    </div>

    <div id="npm-category-name">Restaurants</div>

    <div id="npm-places-list">
        <ul class="npm-place-items-container"></ul>
    </div>
</div>
<?php
    wp_add_inline_script('npm-custom-js', 'const npm_coords = ' . wp_json_encode([
        'lat' => floatval($lat),
        'lng' => floatval($lng),
        'categories' => $categories
    ]) . ';', 'before');

    return ob_get_clean();
}
add_shortcode('nearby_places', 'npm_nearby_places_shortcode');