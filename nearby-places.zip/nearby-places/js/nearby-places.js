jQuery(document).ready(function($) {

    if (!npm_coords || typeof L === 'undefined') return;

    const map = L.map('npm-map').setView([npm_coords.lat, npm_coords.lng], 14);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19
    }).addTo(map);

    const markers = {};
    const allPlaces = {};
    const list = $('.npm-place-items-container');
    const filters = $('.npm-category-filters');

    const RADIUS_SEQUENCE = [5000, 8000, 12000];
    const MAX_RESULTS = 10;

    const centerIcon = L.icon({
        iconUrl: npm_data.plugin_url + 'img/center-marker.png',
        iconSize: [32, 37],
        iconAnchor: [16, 37]
    });

    const centerMarker = L.marker([npm_coords.lat, npm_coords.lng], { icon: centerIcon }).addTo(map);

    /* DISTANCE FUNCTION */
    function calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371;
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a =
            Math.sin(dLat / 2) ** 2 +
            Math.cos(lat1 * Math.PI / 180) *
            Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) ** 2;

        return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
    }

    /* ADD MARKER */
    function addMarker(place) {
        const icon = L.icon({
            iconUrl: npm_data.plugin_url + 'img/marker-' + place.mainCategory + '.png',
            iconSize: [32, 37],
            iconAnchor: [16, 37]
        });

        const marker = L.marker([place.lat, place.lon], { icon: icon });

        marker.addTo(map);
        marker.bindPopup(`<b>${place.name}</b><br>${place.distance.toFixed(2)} km`);

        markers[place.id] = marker;

        /* MARKER HOVER → highlight list item */
        marker.on("mouseover", function () {
            $(`li[data-id="${place.id}"]`).addClass("hover-highlight");
        });

        marker.on("mouseout", function () {
            $(`li[data-id="${place.id}"]`).removeClass("hover-highlight");
        });
    }

    /* AUTO-CENTER MAP TO ALL MARKERS */
    function centerMapToAllMarkers() {
        const bounds = L.latLngBounds();

        bounds.extend(centerMarker.getLatLng());

        Object.keys(markers).forEach(k => {
            bounds.extend(markers[k].getLatLng());
        });

        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 15 });
    }

    /* CACHING SYSTEM */
    function cacheKey(category, radius) {
        return `npm_cache_${category}_${radius}`;
    }

    function saveToCache(category, radius, data) {
        sessionStorage.setItem(cacheKey(category, radius), JSON.stringify(data));
    }

    function loadFromCache(category, radius) {
        const raw = sessionStorage.getItem(cacheKey(category, radius));
        if (!raw) return null;

        try {
            return JSON.parse(raw);
        } catch {
            return null;
        }
    }

    /* LOAD CATEGORY FROM OVERPASS WITH FALLBACK RADII */
    async function loadCategory(cat, radiusIndex = 0) {
        const radius = RADIUS_SEQUENCE[radiusIndex];
        const filter = npm_coords.categories[cat];

        list.html(`<li>Searching within ${(radius/1000)} km...</li>`);

        /* Try reading from cache */
        const cached = loadFromCache(cat, radius);
        if (cached) {
            parseOverpassResults(cat, cached);
            return;
        }

        /* Try online request */
        try {
            const res = await $.ajax({
                url: npm_data.ajax_url,
                method: "POST",
                data: {
                    action: "npm_overpass_proxy",
                    nonce: npm_data.nonce,
                    lat: npm_coords.lat,
                    lng: npm_coords.lng,
                    radius: radius,
                    filter: filter
                },
                dataType: "json",
                timeout: 8000
            });

            if (!res.success || !Array.isArray(res.data)) {
                throw new Error("Invalid response");
            }

            /* If found some data, save to cache and process */
            if (res.data.length > 0) {
                saveToCache(cat, radius, res.data);
                parseOverpassResults(cat, res.data);
                return;
            }

            /* If nothing found, try next radius */
            if (radiusIndex + 1 < RADIUS_SEQUENCE.length) {
                loadCategory(cat, radiusIndex + 1);
                return;
            }

            list.html('<li>No nearby places found</li>');

        } catch (e) {
            /* Network / Overpass failure */
            list.html(`
                <li style="color:red;">Connection failed. Check internet.</li>
                <li>Retrying...</li>
            `);

            setTimeout(() => loadCategory(cat, radiusIndex), 2000);
        }
    }

    /* PARSE RESULTS */
    function parseOverpassResults(cat, data) {
        allPlaces[cat] = [];

        data.forEach(item => {
            const lat = item.lat || item.center?.lat;
            const lon = item.lon || item.center?.lon;

            if (!lat || !lon) return;

            const name = item.tags?.name || item.tags?.brand || "Unnamed";
            const distance = calculateDistance(npm_coords.lat, npm_coords.lng, lat, lon);

            allPlaces[cat].push({
                id: cat + '-' + item.id,
                lat,
                lon,
                name,
                distance,
                mainCategory: cat
            });
        });

        renderList(cat);
    }

    /* RENDER LIST + MARKERS */
    function renderList(cat) {

        list.empty();

        map.eachLayer(layer => {
            if (layer instanceof L.Marker && layer !== centerMarker) {
                map.removeLayer(layer);
            }
        });

        Object.keys(markers).forEach(id => delete markers[id]);

        if (!allPlaces[cat].length) {
            list.html('<li>No nearby places found</li>');
            return;
        }

        const finalList = allPlaces[cat]
            .sort((a, b) => a.distance - b.distance)
            .slice(0, MAX_RESULTS);

        finalList.forEach(place => {
            addMarker(place);

            list.append(`
                <li class="npm-place-item" data-id="${place.id}">
                    <img src="${npm_data.plugin_url}img/marker-${place.mainCategory}.png" class="npm-list-marker-icon">
                    <span class="npm-title">${place.name}</span>
                    <span class="npm-distance">${place.distance.toFixed(2)} km</span>
                </li>
            `);
        });

        centerMapToAllMarkers();
    }

    /* CLICK → FLY TO MARKER + OPEN POPUP */
    list.on('click', '.npm-place-item', function () {
        const id = $(this).data('id');
        const marker = markers[id];

        if (!marker) return;

        const target = marker.getLatLng();

        map.flyTo(target, 16, {
            animate: true,
            duration: 1
        });

        setTimeout(() => {
            marker.openPopup();
            marker.bringToFront();
        }, 700);

        document.getElementById("npm-map").scrollIntoView({ behavior: "smooth" });
    });

    /* LIST HOVER → MARKER OPACITY CHANGE */
    list.on('mouseenter', '.npm-place-item', function () {
        const marker = markers[$(this).data('id')];
        if (marker) marker.setOpacity(0.5);
    });

    list.on('mouseleave', '.npm-place-item', function () {
        const marker = markers[$(this).data('id')];
        if (marker) marker.setOpacity(1);
    });

    /* CATEGORY CLICK */
    filters.on('click', '.npm-filter', function() {
        const cat = $(this).data('category');

        filters.find('.active').removeClass('active');
        $(this).addClass('active');

        $('#npm-category-name').text(cat.replace(/_/g, ' ').toUpperCase());

        if (allPlaces[cat]) {
            renderList(cat);
        } else {
            loadCategory(cat);
        }
    });

    filters.find('[data-category="restaurants"]').click();
});
